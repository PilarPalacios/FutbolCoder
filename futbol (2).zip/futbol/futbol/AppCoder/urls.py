from django.urls import path
from AppCoder import views

urlpatterns = [
    
    path('', views.inicio, name="Inicio"), #esta era nuestra primer view
    path('cups', views.cups, name="cups"),
    path('matches', views.matches, name="Matches"),
    path('players', views.players, name="Players"),
    

    ]