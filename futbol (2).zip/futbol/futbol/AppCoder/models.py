from django.db import models

# Create your models here.
class Cups(models.Model):

    anio= models.IntegerField()
    pais=models.CharField(max_length=40)
    campeon=models.CharField(max_length=40)

class Matches(models.Model):
    
    fecha= models.DateField()
    pais= models.CharField(max_length=30)  
    rival_1= models.CharField(max_length=30) 
    rival_2= models.CharField(max_length=30) 


class Players(models.Model):
    
    nacionalidad= models.CharField(max_length=30)  
    nombre= models.CharField(max_length=30) 
    

