from django.shortcuts import render, HttpResponse
from django.http import HttpResponse
from AppCoder.models import Cups,Players,Matches

def inicio(request):

      return render(request, "AppCoder/inicio.html")

def cups(request):

      return render(request, "AppCoder/cups.html")

def players(request):

      return render(request, "AppCoder/players.html")
    
def matches(request):

      return render(request, "AppCoder/matches.html")